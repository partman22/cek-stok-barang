import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;

void main() => runApp(StockApp());

class StockApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Cek Stock Barang',
      theme: ThemeData(
        useMaterial3: true,
      ),
      home: StockPage(),
    );
  }
}

class StockPage extends StatefulWidget {
  @override
  _StockPageState createState() => _StockPageState();
}

class _StockPageState extends State<StockPage> {
  List<dynamic> _allItems = [];
  List<dynamic> _filteredItems = [];
  TextEditingController _controller = TextEditingController();

  @override
  void initState() {
    super.initState();
    loadJsonData();
  }

  void loadJsonData() async {
    String jsonString = await rootBundle.loadString('assets/data_stock.json');
    final List<dynamic> jsonResponse = json.decode(jsonString);
    setState(() {
      _allItems = jsonResponse;
      _filteredItems = jsonResponse;
    });
  }

  void _filterItems(String query) {
    final results = _allItems.where((item) => item['no_part'].toString().toLowerCase().contains(query.toLowerCase())).toList();
    setState(() {
      _filteredItems = results;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Cek Stock Barang')),
      body: Column(
        children: [
          Padding(
            padding: EdgeInsets.all(10),
            child: TextField(
              controller: _controller,
              decoration: InputDecoration(
                labelText: 'Cari berdasarkan No Part',
                border: OutlineInputBorder(),
              ),
              onChanged: _filterItems,
            ),
          ),
          Expanded(
            child: _filteredItems.isEmpty
                ? Center(child: Text('Tidak ada data'))
                : ListView.builder(
                    itemCount: _filteredItems.length,
                    itemBuilder: (context, index) {
                      final item = _filteredItems[index];
                      return Card(
                        margin: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                        child: ListTile(
                          title: Text(item['nama_part'] ?? 'Tanpa Nama'),
                          subtitle: Text('No Part: ${item['no_part']}'),
                          trailing: Text('Qty: ${item['qty']}'),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
